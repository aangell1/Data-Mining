import numpy as np
import tensorflow as tf
from surprise import Dataset, Reader
from sklearn.model_selection import train_test_split
import time

def build_deep_learning_model(n_users, n_items, n_factors=50):
    user_input = tf.keras.layers.Input(shape=(1,), name='User_Input')
    item_input = tf.keras.layers.Input(shape=(1,), name='Item_Input')

    user_embedding = tf.keras.layers.Embedding(input_dim=n_users, output_dim=n_factors, name='User_Embedding')(user_input)
    item_embedding = tf.keras.layers.Embedding(input_dim=n_items, output_dim=n_factors, name='Item_Embedding')(item_input)

    user_vec = tf.keras.layers.Flatten()(user_embedding)
    item_vec = tf.keras.layers.Flatten()(item_embedding)

    concat = tf.keras.layers.Concatenate()([user_vec, item_vec])

    dense1 = tf.keras.layers.Dense(128, activation='relu')(concat)
    dense2 = tf.keras.layers.Dense(64, activation='relu')(dense1)
    output = tf.keras.layers.Dense(1, activation='linear', name='Output')(dense2)

    model = tf.keras.Model(inputs=[user_input, item_input], outputs=output)
    model.compile(optimizer='adam', loss='mse', metrics=['mae'])
    return model

def preprocess_data_for_dl(ratings_df):
    user_ids = ratings_df['user_id'].unique()
    item_ids = ratings_df['movie_id'].unique()

    user_map = {u: i for i, u in enumerate(user_ids)}
    item_map = {i: j for j, i in enumerate(item_ids)}

    ratings_df['user_id'] = ratings_df['user_id'].map(user_map)
    ratings_df['movie_id'] = ratings_df['movie_id'].map(item_map)
    X = ratings_df[['user_id', 'movie_id']].values
    y = ratings_df['rating'].values
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    return X_train, X_test, y_train, y_test, len(user_ids), len(item_ids)

def train_and_evaluate_dl_model(ratings_df, n_factors=50, epochs=10, batch_size=32):
    X_train, X_test, y_train, y_test, n_users, n_items = preprocess_data_for_dl(ratings_df)
    model = build_deep_learning_model(n_users, n_items, n_factors=n_factors)
    model.fit([X_train[:, 0], X_train[:, 1]], y_train, epochs=epochs, batch_size=batch_size, verbose=1)
    
    start_time = time.time()
    loss, mae = model.evaluate([X_test[:, 0], X_test[:, 1]], y_test, verbose=1)
    end_time = time.time()
    elapsed_time = end_time - start_time
    
    print(f"Deep Learning Model Results:\nLoss (MSE): {loss:.4f}\nMAE: {mae:.4f}")
    print(f"Elapsed time: {elapsed_time} seconds")
    return model

if __name__ == "__main__":
    import pandas as pd
    from data_preprocessing import load_and_preprocess_data 
    data_path = "./u.data"
    ratings_df, _ = load_and_preprocess_data(data_path)
    train_and_evaluate_dl_model(ratings_df, n_factors=50, epochs=10, batch_size=64)
