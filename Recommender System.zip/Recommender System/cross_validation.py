from surprise.model_selection import KFold

def perform_cross_validation(surprise_data, n_splits=5):
    """
    Perform 5-fold cross-validation on the dataset.
    Args:
        surprise_data (Dataset): Surprise dataset object.
        n_splits (int): Number of splits for cross-validation.
    Returns:
        list: Train and test splits for cross-validation.
    """
    kf = KFold(n_splits=n_splits)
    
    folds = []
    
    for trainset, testset in kf.split(surprise_data):
        folds.append((trainset, testset))
    
    return folds

if __name__ == "__main__":
    from data_preprocessing import load_and_preprocess_data
    
    data_path = "./u.data"
    _, surprise_data = load_and_preprocess_data(data_path)

    folds = perform_cross_validation(surprise_data, n_splits=5)
    print(f"Number of folds: {len(folds)}")
    
    trainset_ratings = list(folds[0][0].all_ratings())
    print(f"Trainset size (first fold): {len(trainset_ratings)}")
    print(f"Testset size (first fold): {len(folds[0][1])}")

