import pandas as pd
from surprise import Dataset, Reader

def load_and_preprocess_data(data_path):
    columns = ['user_id', 'movie_id', 'rating', 'timestamp']
    ratings_df = pd.read_csv(data_path, sep='\t', names=columns)
    
    ratings_df.drop('timestamp', axis=1, inplace=True)
    
    reader = Reader(line_format='user item rating', sep='\t')
    surprise_data = Dataset.load_from_df(ratings_df[['user_id', 'movie_id', 'rating']], reader)
    
    return ratings_df, surprise_data

if __name__ == "__main__":
    data_path = "./u.data"
    ratings_df, surprise_data = load_and_preprocess_data(data_path)
    print("Preprocessed DataFrame:")
    print(ratings_df.head())
