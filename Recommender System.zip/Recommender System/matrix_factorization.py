import numpy as np
from surprise import AlgoBase, Dataset, Reader, accuracy
from surprise.model_selection import KFold
import time

class MatrixFactorization(AlgoBase):
    def __init__(self, n_factors=20, n_epochs=20, learning_rate=0.005, reg=0.02):
        super().__init__()
        self.n_factors = n_factors
        self.n_epochs = n_epochs
        self.learning_rate = learning_rate
        self.reg = reg

    def fit(self, trainset):
        # Initialize user and item latent factor matrices
        self.trainset = trainset
        n_users = trainset.n_users
        n_items = trainset.n_items
        
        self.p = np.random.normal(0, 0.1, (n_users, self.n_factors))  # User latent factors
        self.q = np.random.normal(0, 0.1, (n_items, self.n_factors))  # Item latent factors
        self.bu = np.zeros(n_users)  # User biases
        self.bi = np.zeros(n_items)  # Item biases
        self.global_mean = self.trainset.global_mean  # Global average rating

        # Perform SGD
        for epoch in range(self.n_epochs):
            for u, i, r in self.trainset.all_ratings():
                err = r - self.predict_single(u, i)
                # Update biases
                self.bu[u] += self.learning_rate * (err - self.reg * self.bu[u])
                self.bi[i] += self.learning_rate * (err - self.reg * self.bi[i])
                # Update latent factors
                self.p[u, :] += self.learning_rate * (err * self.q[i, :] - self.reg * self.p[u, :])
                self.q[i, :] += self.learning_rate * (err * self.p[u, :] - self.reg * self.q[i, :])

        return self

    def predict_single(self, u, i):
        if not (self.trainset.knows_user(u) and self.trainset.knows_item(i)):
            return self.global_mean
        pred = self.global_mean + self.bu[u] + self.bi[i] + np.dot(self.p[u, :], self.q[i, :])
        return pred

    def estimate(self, u, i):
        return self.predict_single(u, i)

def evaluate_mf_model(folds, n_factors=20, n_epochs=20, learning_rate=0.005, reg=0.02):
    rmses = []
    maes = []

    for trainset, testset in folds:
        algo = MatrixFactorization(n_factors=n_factors, n_epochs=n_epochs, learning_rate=learning_rate, reg=reg)
        algo.fit(trainset)
        
        start_time = time.time()
        predictions = algo.test(testset)
        end_time = time.time()
        elapsed_time = end_time - start_time
        rmse = accuracy.rmse(predictions, verbose=False)
        mae = accuracy.mae(predictions, verbose=False)
        rmses.append(rmse)
        maes.append(mae)

    print(f"Matrix Factorization Results:\nAverage RMSE: {np.mean(rmses):.4f}\nAverage MAE: {np.mean(maes):.4f}")
    print(f"Elapsed time: {elapsed_time} seconds")
    return algo
    
if __name__ == "__main__":
    from data_preprocessing import load_and_preprocess_data
    from cross_validation import perform_cross_validation

    data_path = "./u.data"
    _, surprise_data = load_and_preprocess_data(data_path)
    folds = perform_cross_validation(surprise_data, n_splits=5)
    
    evaluate_mf_model(folds, n_factors=20, n_epochs=30, learning_rate=0.01, reg=0.1)
