import random
import numpy as np
from surprise import accuracy
import time

def random_predictions(testset, min_rating=1, max_rating=5):
    predictions = []
    for uid, iid, true_rating in testset:
        pred_rating = random.uniform(min_rating, max_rating)
        predictions.append((uid, iid, true_rating, pred_rating, {}))  # Includes the `details` field
    return predictions

def evaluate_random_model(folds, min_rating=1, max_rating=5):
    rmses = []
    maes = []
    
    for trainset, testset in folds:
        start_time = time.time()
        
        predictions = random_predictions(testset, min_rating, max_rating)
        
        end_time = time.time()
        elapsed_time = end_time - start_time
        
        rmse = accuracy.rmse(predictions, verbose=True)
        mae = accuracy.mae(predictions, verbose=True)
        rmses.append(rmse)
        maes.append(mae)
    
    print(f"Random Model Results:\nAverage RMSE: {sum(rmses) / len(rmses):.4f}\nAverage MAE: {sum(maes) / len(maes):.4f}")
    print(f"Elapsed time: {elapsed_time} seconds")

if __name__ == "__main__":
    from data_preprocessing import load_and_preprocess_data
    from cross_validation import perform_cross_validation
    
    data_path = "./u.data"
    _, surprise_data = load_and_preprocess_data(data_path)
    folds = perform_cross_validation(surprise_data, n_splits=5)
    
    evaluate_random_model(folds)

