from deep_learning_model import *
from knn_model import *
from random_model import *
from svd_model import *
from matrix_factorization import *
from data_preprocessing import load_and_preprocess_data
from cross_validation import perform_cross_validation
from surprise import accuracy

data_path = "./u.data"
_, surprise_data = load_and_preprocess_data(data_path)
folds = perform_cross_validation(surprise_data, n_splits=5)

sim_options = {
    'name': 'cosine',
    'user_based': False
}


svdModel = evaluate_svd_model(folds)
print(svdModel)
knnModel = evaluate_knn_model(folds,sim_options)
matriFactorizationModel = evaluate_mf_model(folds, n_factors=20, n_epochs=30, learning_rate=0.01, reg=0.1)

data_path = "./u.data"
ratings_df, _ = load_and_preprocess_data(data_path)
neuralNetworkModel = train_and_evaluate_dl_model(ratings_df, n_factors=50, epochs=10, batch_size=64)

randomsvdrmses = []
randomknnrmses = []
randommfrmses = []

svdknnrsmes = []
svdmfrmses = []

knnmfrmses = []

print("5X5")
for trainset, testset in folds:
    randomPredictions = random_predictions(testset, min_rating=1, max_rating=5)
    svdPredictions = svdModel.test(testset)
    knnPredictions = knnModel.test(testset)
    mfpredictions = matriFactorizationModel.test(testset)
    
    randomsvd = randomPredictions + svdPredictions
    rmse = accuracy.rmse(randomsvd, verbose=False)
    randomsvdrmses.append(rmse)

    randomknn = randomPredictions + knnPredictions
    rmse = accuracy.rmse(randomknn, verbose=False)
    randomknnrmses.append(rmse)

    randomf = randomPredictions + mfpredictions
    rmse = accuracy.rmse(randomf, verbose=False)
    randommfrmses.append(rmse)
    
    svdknn = svdPredictions + knnPredictions
    rmse = accuracy.rmse(svdknn, verbose=False)
    svdknnrsmes.append(rmse)
    
    svdmmf = svdPredictions + mfpredictions
    rmse = accuracy.rmse(svdmmf, verbose=False)
    svdmfrmses.append(rmse)
    
    knnmf = knnPredictions + mfpredictions
    rmse = accuracy.rmse(knnmf, verbose=False)
    knnmfrmses.append(rmse)
    
print(f"Random Model Results:\nAverage RMSE: {sum(randomsvdrmses) / len(randomsvdrmses):.4f}\n")
print(f"Random Model Results:\nAverage RMSE: {sum(randomknnrmses) / len(randomknnrmses):.4f}\n_epochs")
print(f"Random Model Results:\nAverage RMSE: {sum(randommfrmses) / len(randommfrmses):.4f}\n")
print(f"Random Model Results:\nAverage RMSE: {sum(svdknnrsmes) / len(svdknnrsmes):.4f}\n")
print(f"Random Model Results:\nAverage RMSE: {sum(svdmfrmses) / len(svdmfrmses):.4f}\n")
print(f"Random Model Results:\nAverage RMSE: {sum(knnmfrmses) / len(knnmfrmses):.4f}\n")

