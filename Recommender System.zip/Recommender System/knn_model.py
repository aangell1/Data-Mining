from surprise import KNNBasic, accuracy
import time

def train_knn_model(trainset, sim_options):
    algo = KNNBasic(k=35,sim_options=sim_options)
    algo.fit(trainset)
    return algo

def evaluate_knn_model(folds, sim_options):
    rmses = []
    maes = []
    
    for trainset, testset in folds:
        algo = train_knn_model(trainset, sim_options)
        start_time = time.time()
        predictions = algo.test(testset)
        end_time = time.time()
        elapsed_time = end_time - start_time
        rmse = accuracy.rmse(predictions, verbose=False)
        mae = accuracy.mae(predictions, verbose=False)
        
        rmses.append(rmse)
        maes.append(mae)
    
    print(f"kNN Model Results:\nAverage RMSE: {sum(rmses) / len(rmses):.4f}\nAverage MAE: {sum(maes) / len(maes):.4f}")
    print(f"Elapsed time: {elapsed_time} seconds")
    return algo

if __name__ == "__main__":
    from data_preprocessing import load_and_preprocess_data
    from cross_validation import perform_cross_validation

    data_path = "./u.data"
    _, surprise_data = load_and_preprocess_data(data_path)
    folds = perform_cross_validation(surprise_data, n_splits=5)
    
    sim_options = {
        'name': 'cosine',
        'user_based': False
    }
    evaluate_knn_model(folds, sim_options)
