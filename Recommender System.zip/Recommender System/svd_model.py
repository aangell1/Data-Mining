from surprise import SVD, accuracy
import time

def train_svd_model(trainset):
    algo = SVD(n_factors=80,n_epochs=20, init_std_dev=.05)
    algo.fit(trainset)
    return algo

def evaluate_svd_model(folds):
    rmses = []
    maes = []
    
    for trainset, testset in folds:
        algo = train_svd_model(trainset)
        
        start_time = time.time()

        predictions = algo.test(testset)
        
        end_time = time.time()
        elapsed_time = end_time - start_time
        rmse = accuracy.rmse(predictions, verbose=False)
        mae = accuracy.mae(predictions, verbose=False)
        
        rmses.append(rmse)
        maes.append(mae)
    
    print(f"SVD Model Results:\nAverage RMSE: {sum(rmses) / len(rmses):.4f}\nAverage MAE: {sum(maes) / len(maes):.4f}")
    print(f"Elapsed time: {elapsed_time} seconds")
    return algo
      
if __name__ == "__main__":
    from data_preprocessing import load_and_preprocess_data
    from cross_validation import perform_cross_validation

    data_path = "./u.data"
    _, surprise_data = load_and_preprocess_data(data_path)
    folds = perform_cross_validation(surprise_data, n_splits=5)
    
    evaluate_svd_model(folds)
